"""I have 302 lines of code"""

import turtle
import random


#########My Turtles########
                          #
board = turtle.Turtle()   #
                          #
backdrop = turtle.Screen()

Player1 = turtle.Turtle()
Player1.hideturtle()
Player1.speed(0)

Player2 = turtle.Turtle()
Player2.hideturtle()
Player2.speed(0)

Object = turtle.Turtle()
Object.hideturtle()
Object.speed(7)


Dice = turtle.Turtle()
Dice.hideturtle()
Dice.speed(7)


Number = turtle.Turtle()
Number.hideturtle()
Number.speed(0)


Winner = turtle.Turtle()
Winner.hideturtle()       #
                          #
                          #
###########################

                        


"""
GRID CREATIONS
"""


def GridDirections(t,x,y,magnitude):
    t.penup()
    t.goto(x,y)
    t.pendown()
    for i in range(0,4):
        board.forward(magnitude)
        board.right(90)


def BoardCreation():
    board.speed(0)   #The speed at which the grid is made
    board.pensize(5)
    board.hideturtle()
    backdrop.bgcolor("lightblue")#sets the background color
    
    latitude = -400 #Placement of the starting point
    longitude = -230
    box_size = 150 #size of each individual box
    for i in range(0,5):
        for j in range(0,5):
            GridDirections(board,latitude + j*box_size, longitude + i*box_size, box_size)

def TileNumber():

    Number.penup
    Number.speed(0)   #The speed at which the grid is made
    Number.hideturtle()

    count=0
    
    Tile=[1,2,3,4,5,10,9,8,7,6,11,12,13,14,15,20,19,18,17,16,21,22,23,24,25]

    
    
    
    latitude = -375 #Placement of the starting point
    longitude = -280
    box_size = 150 #size of each individual box
    for i in range(0,5):
        for j in range(0,5):
            GridDirections(Number,latitude + j*box_size, longitude + i*box_size, 0)
            Number.write(Tile[count], font=("Comic Sans MS", 20, "normal"))
            count=count+1    
            

"""
SNAKES AND LADDERS
"""



def DrawObject(image,x,y):

    turtle.register_shape(image)

    Object.shape(image)
    Object.penup()
    Object.goto(x,y)
    Object.pendown
    Object.showturtle()
    return Object.stamp()

def RunDrawObject():
    
    DrawObject('ladder.gif',22,219)    #These set of instructions place the snakes and ladders
    DrawObject('ladder2.gif',-165,-82)
    DrawObject('ladder3.gif',272,-155)
    DrawObject('snake2.gif',-19,-236)
    DrawObject('snake.gif',121,145)
    DrawObject('snake3.gif',-320,-81)
    



"""
DICE DISPLAY
"""

def Dice2():
    Dice.penup()
    Dice.goto((410,25))
    Dice.pendown()
    Dice.showturtle()

    turtle.register_shape('dice1.gif')
    turtle.register_shape('dice2.gif')
    turtle.register_shape('dice3.gif')
    turtle.register_shape('dice4.gif')
    turtle.register_shape('dice5.gif')
    turtle.register_shape('dice6.gif')

def MoveSize():
    return random.randint(1,6)
    #Selects a random dice roll between 1 and 6


def DicePos():
    
    Dice.shape
    Dice.penup()
    Dice.goto((410,25))
    Dice.pendown()
    Dice.showturtle()



"""
IMAGE REGISTER
"""

def bull():

    turtle.register_shape('bull.gif')
    Player1.shape("bull.gif")
    Player1.speed(5)
    Player1.penup()
    Player1.goto(-350,-320)
    Player1.pendown
    Player1.showturtle()

def cow():

    turtle.register_shape('cow.gif')
    Player2.shape("cow.gif")
    Player2.speed(5)
    Player2.penup()
    Player2.goto(-286,-274)
    Player2.pendown
    Player2.showturtle()





"""
WINNING SCREEN
"""

def WinningScreen():

    
    turtle.register_shape('win.gif')
    Winner.shape('win.gif')
    Winner.showturtle()
    backdrop.bgcolor("lightgreen")
    


"""
TURN SYSTEM
"""





def TurnSystem():
    
    gg = False
    turn = 0
    
    BullLocation = 1
    CowLocation = 1
    
#The location Variables are used in conjunction with the counter variable so that
#the Player.turtles constantly update their location
    
    endtileC = 0
    endtileB = 0
    
#The Since the turtle square is constantly being checked Player.turtles would always
#go up/down any ladder/snake it came across, The endtile variable is used so that they
#they only go up/down if it's the tile they land on

    while not gg:
    
        if turn == 0:
            holder = input("Big Bad Bull: Press Enter to Roll ")
            Roll = MoveSize()
            counter = Roll
            
#The Counter Variable is used to make the turtle check its
#tile every move to verify whether ot not it needs to turn            

            
            print("You rolled a "+str(Roll))

            if Roll == 1:
                Dice.shape('dice1.gif')
            elif Roll == 2:
                Dice.shape('dice2.gif')
            elif Roll == 3:
                Dice.shape('dice3.gif')
            elif Roll == 4:
                Dice.shape('dice4.gif')
            elif Roll == 5:
                Dice.shape('dice5.gif')
            else:
                Dice.shape('dice6.gif')
                
            endtileB = BullLocation + Roll
            
            while counter > 0 and BullLocation < 26:

                
                counter = counter-1
                if counter == 0 and BullLocation <25:
                    print("You landed on tile "+str(endtileB))
                
#CORNER TILE MOVEMENT CORRETION                              
                
                if BullLocation ==5:
                    Player1.left(90)
                
                if BullLocation ==6:
                    Player1.left(90)                    

                if BullLocation ==10:
                    Player1.left(270)
                    
                if BullLocation ==11:
                    Player1.left(270)

                if BullLocation ==15:
                    Player1.setheading(90)

                if BullLocation ==16:
                    Player1.left(90)

                if BullLocation ==20:
                    Player1.left(270)
                    
                if BullLocation ==21:
                    Player1.left(270)

                if BullLocation == 25 or endtileB == 25:
                    print("")
                    print("CONGRATULATIONS BIG BAD BULL YOU WON")
                    counter = 0
                    gg = True
                    
                
                  
                else:
                    BullLocation = BullLocation+1
                    Player1.forward(150)

#SNAKE AND LADDER MOVEMENT CORRECTION SYSTEM
                    
            if endtileB ==8:#SNAKE1
                Player1.left(90)
                Player1.forward(150)
                Player1.left(90)
                BullLocation = 3
                print("Oh no! You slid down to tile 3")

            elif endtileB ==20:#SNAKE2
                Player1.left(90)
                Player1.forward(450)
                Player1.left(90)
                BullLocation = 1
                print("Oh no! You slid down to tile 1")

            elif endtileB ==24:#SNAKE3
                Player1.right(90)
                Player1.forward(300)
                Player1.left(90)
                BullLocation = 14
                print("Oh no! You slid down to tile 14")
                
            elif endtileB ==5:#LADDER1
                Player1.left(90)
                Player1.forward(300)
                Player1.left(90)
                BullLocation = 15
                print("WOW! You climbed up to tile 15")
                
            elif endtileB ==9:#LADDER2
                Player1.right(90)
                Player1.forward(150)
                Player1.right(90)
                BullLocation = 12
                print("WOW! You climbed up to tile 12")
                
            elif endtileB ==18:#LADDER3
                Player1.right(90)
                Player1.forward(150)
                Player1.right(90)
                BullLocation = 23
                print("WOW! You climbed up to tile 23")
               


        elif holder == input("Fluffy Cow: Press Enter to Roll "):
            Roll = MoveSize()
            counter = Roll
            

            
            print("You rolled a "+str(Roll))
            
            if Roll == 1:
                Dice.shape('dice1.gif')
            elif Roll == 2:
                Dice.shape('dice2.gif')
            elif Roll == 3:
                Dice.shape('dice3.gif')
            elif Roll == 4:
                Dice.shape('dice4.gif')
            elif Roll == 5:
                Dice.shape('dice5.gif')
            else:
                Dice.shape('dice6.gif')


            endtileC = CowLocation + Roll

                
            while counter > 0 and CowLocation < 26: 
                counter = counter-1
                
                if counter == 0 and CowLocation <25:
                    print("You landed on tile "+str(endtileC))

#CORNER TILE MOVEMENT CORRETION 
                
                if CowLocation ==5:
                    Player2.left(90)
                
                if CowLocation ==6:
                    Player2.left(90)

                if CowLocation ==10:
                    Player2.left(270)
                    
                if CowLocation ==11:
                    Player2.left(270)

                if CowLocation ==15:
                    Player2.setheading(90)

                if CowLocation ==16:
                    Player2.left(90)

                if CowLocation ==20:
                    Player2.left(270)
                    
                if CowLocation ==21:
                    Player2.left(270)

                if CowLocation == 25 or endtileC ==25:
                    print("")
                    print("CONGRATULATIONS FLUFFY COW YOU WON")
                    counter = 0
                    gg = True
                    
                else:
                    CowLocation = CowLocation+1
                    Player2.forward(150)

#SNAKE AND LADDER MOVEMENT CORRECTION SYSTEM
                    
            if endtileC ==8:#SNAKE1
                Player2.left(90)
                Player2.forward(150)
                Player2.left(90)
                CowLocation = 3
                print("Oh no! You slid down to tile 3")
                
            elif endtileC ==20:#SNAKE2
                Player2.left(90)
                Player2.forward(450)
                Player2.left(90)
                CowLocation = 1
                print("Oh no! You slid down to tile 1")
                
            elif endtileC ==24:#SNAKE3
                Player2.right(90)
                Player2.forward(300)
                Player2.left(90)
                CowLocation = 14
                print("Oh no! You slid down to tile 14")
                
            elif endtileC ==5:#LADDER1
                Player2.left(90)
                Player2.forward(300)
                Player2.left(90)
                CowLocation = 15
                print("WOW! You climbed up to tile 15")
                
            elif endtileC ==9:#LADDER2
                Player2.right(90)
                Player2.forward(150)
                Player2.right(90)
                CowLocation = 12
                print("WOW! You climbed up to tile 12")
                
            elif endtileC ==18:#LADDER3
                Player2.right(90)
                Player2.forward(150)
                Player2.right(90)
                CowLocation = 23
                print("WOW! You climbed up to tile 23")            
            

#This Command alterates the rounds between 1 and 0 through division
        print("")
        turn += 1
        turn = turn % 2
        

        
    else:
        
        WinningScreen()
        Restart = input("Press Enter to play again")
        if Restart =="":#if they enter any input instead the game will end
            BoardReset()
            


"""
BOARD RESET
"""

def BoardReset():
    backdrop.bgcolor("lightblue")
    Winner.hideturtle()
    Player1.reset()
    Player2.reset()
    cow()
    bull()
    TurnSystem()

"""
FIRST RUN OF CODE
"""
    

BoardCreation()                    #This Creates the Board

TileNumber()                       #This Numbers The Board

RunDrawObject()                    #This Places The Snakes and Ladders

Dice2()                            #This sets up Dice Position and Registers its images

bull()                             #This sets up the Bull's Starting postion

cow()                              #This sets up the Cows's Starting postion

TurnSystem()                       #This Runs The Game



